package eecs.berkeley.edu.cs294;

import java.io.Serializable;

public class MyTodo implements Serializable{

	private static final long serialVersionUID = 223L;

	public String name = "";
	public double budget = 0;
	public int eventID = 0;


	public String getTodoName() {
		return name;
	}
	public void setTodoName(String name) {
		this.name = name;
	}
	public int getTodoID() {
		return eventID;
	}
	public void setTodoID(Integer eventID) {
		this.eventID = eventID;
	}
	public double getTodoBudget() {
		return budget;
	}
	public void setTodoBudget(Integer budget) {
		this.budget = budget;
	}
}